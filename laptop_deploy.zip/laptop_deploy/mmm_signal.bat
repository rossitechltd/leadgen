@echo off
REM Use this from Mini Mouse Macro "Run Program" steps.
REM Examples:
REM   mmm_signal.bat SAFE
REM   mmm_signal.bat BUSY
REM   mmm_signal.bat LOOP2_DONE

cd /d "%~dp0"
call venv\Scripts\activate.bat
python scripts\mmm_signal.py %*
