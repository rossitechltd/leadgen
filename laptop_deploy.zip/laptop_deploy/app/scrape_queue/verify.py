"""Scrape result verification for Step 3 queue."""

from __future__ import annotations

import re
from dataclasses import dataclass

FAILURE_PATTERNS: tuple[re.Pattern[str], ...] = tuple(
    re.compile(pattern, re.IGNORECASE)
    for pattern in (
        r"log\s*in",
        r"login",
        r"sign\s*in",
        r"content isn'?t available",
        r"page not found",
        r"this page isn'?t available",
        r"something went wrong",
        r"checkpoint",
        r"you must log in",
    )
)


@dataclass(frozen=True)
class VerifyResult:
    ok: bool
    reason: str = ""


def verify_scrape_text(text: str, *, min_length: int = 50) -> VerifyResult:
    cleaned = (text or "").strip()
    if not cleaned:
        return VerifyResult(ok=False, reason="empty scrape")

    if len(cleaned) < min_length:
        return VerifyResult(ok=False, reason=f"too short ({len(cleaned)} chars)")

    for pattern in FAILURE_PATTERNS:
        if pattern.search(cleaned):
            return VerifyResult(ok=False, reason=f"matched error pattern: {pattern.pattern}")

    return VerifyResult(ok=True)
