"""Scrape queue state persisted outside the 2-column scrapesheet."""

from __future__ import annotations

import json
import logging
from dataclasses import asdict, dataclass
from pathlib import Path

from app.config import Settings, get_settings

logger = logging.getLogger(__name__)


@dataclass
class ActiveScrapeState:
    source_row: int
    attempt: int
    link: str


class ScrapeStateStore:
    def __init__(self, path: Path) -> None:
        self.path = path

    def load(self) -> ActiveScrapeState | None:
        if not self.path.exists():
            return None
        try:
            raw = json.loads(self.path.read_text(encoding="utf-8"))
            return ActiveScrapeState(
                source_row=int(raw["source_row"]),
                attempt=int(raw.get("attempt", 1)),
                link=str(raw.get("link", "")),
            )
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            logger.warning("Invalid scrape state file %s: %s", self.path, exc)
            return None

    def save(self, state: ActiveScrapeState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(asdict(state), indent=2), encoding="utf-8")

    def clear(self) -> None:
        if self.path.exists():
            self.path.unlink()


def get_state_store(settings: Settings | None = None) -> ScrapeStateStore:
    settings = settings or get_settings()
    return ScrapeStateStore(settings.scrape_state_path)
