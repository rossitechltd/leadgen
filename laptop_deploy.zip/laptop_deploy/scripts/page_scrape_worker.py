#!/usr/bin/env python3
"""24/7 Windows worker: keep Loop 1 running and reorder pending leads safely.

Run on the Windows laptop alongside Mini Mouse Macro:

  python scripts/page_scrape_worker.py

The worker:
1. Ensures Loop 1 (scrape macro) is started
2. Polls for pending rows (empty Website Link Scrape)
3. When a pending row is not at row 2, waits for Loop 1 SAFE, moves it, resumes Loop 1
"""

from __future__ import annotations

import logging
import sys
import time
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
load_dotenv(ROOT / ".env")

from app.automation.coordinator import get_coordinator  # noqa: E402
from app.config import get_settings  # noqa: E402

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("page_scrape_worker")


def main() -> int:
    settings = get_settings()
    if not settings.sheets_configured:
        logger.error("Google Sheets not configured — add service account JSON")
        return 1

    coordinator = get_coordinator()
    poll_secs = float(__import__("os").getenv("PAGE_SCRAPE_POLL_SECS", "30"))

    logger.info(
        "Page scrape worker started (poll=%ss, move_via=%s)",
        poll_secs,
        settings.mmm_move_via,
    )
    coordinator.start_loop1()

    while True:
        try:
            status = coordinator.get_status()
            pending = status.get("pending_scrape_rows", 0) or 0
            if pending:
                result = coordinator.process_pending_queue(max_moves=1)
                if result["count"]:
                    logger.info("Queue move: %s", result["moves"][0]["message"])
                elif pending:
                    logger.debug("Top row already set for %s pending lead(s)", pending)
            else:
                logger.debug("No pending scrape rows")
        except Exception:
            logger.exception("Worker loop error")

        time.sleep(poll_secs)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        logger.info("Stopped")
        raise SystemExit(0)
