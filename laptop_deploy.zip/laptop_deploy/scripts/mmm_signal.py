#!/usr/bin/env python3
"""Report Mini Mouse Macro status to the Lead Gen coordinator.

Use from MMM via "Run Program" or a batch file after key points in your macro:

  python scripts/mmm_signal.py SAFE
  python scripts/mmm_signal.py BUSY
  python scripts/mmm_signal.py LOOP2_DONE

Optional UDP mode (no HTTP server needed on the macro machine):

  python scripts/mmm_signal.py SAFE --udp
"""

from __future__ import annotations

import argparse
import json
import socket
import sys
import urllib.error
import urllib.request
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

load_dotenv(ROOT / ".env")

from app.config import get_settings  # noqa: E402


def send_udp(signal: str, detail: str) -> None:
    settings = get_settings()
    payload = signal if not detail else f"{signal}:{detail}"
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.sendto(
            payload.encode("utf-8"),
            (settings.mmm_udp_host, settings.mmm_udp_recv_port),
        )
    print(f"UDP -> {settings.mmm_udp_host}:{settings.mmm_udp_recv_port}: {payload}")


def send_http(signal: str, detail: str, base_url: str) -> None:
    url = f"{base_url.rstrip('/')}/api/step3/coordinator/mmm-signal"
    body = json.dumps({"signal": signal, "detail": detail}).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=10) as response:
        print(json.loads(response.read().decode("utf-8")))


def main() -> int:
    settings = get_settings()
    parser = argparse.ArgumentParser(description="Report MMM signal to coordinator")
    parser.add_argument("signal", help="SAFE, BUSY, LOOP2_DONE, etc.")
    parser.add_argument("detail", nargs="?", default="", help="Optional detail text")
    parser.add_argument(
        "--udp",
        action="store_true",
        help="Send via UDP instead of HTTP (default: HTTP to local app)",
    )
    parser.add_argument(
        "--base-url",
        default=f"http://{settings.host}:{settings.port}",
        help="FastAPI base URL for HTTP mode",
    )
    args = parser.parse_args()

    try:
        if args.udp:
            send_udp(args.signal.upper(), args.detail)
        else:
            send_http(args.signal.upper(), args.detail, args.base_url)
    except (urllib.error.URLError, OSError, TimeoutError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
